<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cálculo de Média</title>
    
</head>
<body>
<?php
    $nome = $_POST['nome'];
    $nota1 = floatval($_POST['nota1']);
    $nota2 = floatval($_POST['nota2']);

    $media = ($nota1 + $nota2) / 2;

    echo "Nome do Aluno:$nome<br>";
    echo "A média do aluno é: $media<br>";

    if ($media >= 6) {
      echo "O aluno está aprovado!";
    } else {
        echo "O aluno está reprovado.";
        }
?>

</body>
</html>
 