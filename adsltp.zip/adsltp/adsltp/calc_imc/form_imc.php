<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultado</title>
    <style>
        body{
            background-color: #f4f4f4;
        }
        h1{
            text-align: center;
        }
        h3{
            text-align: center;
        }

    </style>

</head>
<body>
    <?php 

    $peso = $_POST['peso'];
    $altura = $_POST['altura'];
    $peso2 = str_replace(',','.',$peso);
    $altura2 = str_replace(',','.',$altura);
    $imc = $peso2/($altura2*$altura2);
    
    if($imc< 17){
        echo "<h1>Muito abaixo do peso</h1>";
        echo "<h3>Seu IMC é:".$imc."<h3>";
    }elseif($imc < 18.5){
        echo "<h1>Abaixo do peso</h1>";
        echo "<h3>Seu IMC é:".$imc."<h3>";
    }elseif($imc < 24.99){
        echo "<h1>Peso normal</h1>";
        echo "<h3>Seu IMC é:".$imc."<h3>";
    }elseif($imc < 29.99){
        echo "<h1>Acima do peso</h1>";
        echo "<h3>Seu IMC é:".$imc."<h3>";
    }elseif($imc < 34.90){
        echo "<h1>Obesidade 1</h1>";
        echo "<h3>Seu IMC é:".$imc."<h3>";
    }elseif($imc < 39.99){
        echo "<h1>Obesidade 2 (Severa)</h1>";
        echo "<h3>Seu IMC é:".$imc."<h3>";
    }else{
        echo "<h1>Obesidade 4 (Mórbida)</h1>";
        echo "<h3>Seu IMC é:".$imc."<h3>";
    }
    echo "<br>";
    echo "<a href='form_imc.php'>Voltar</a>";
    ?>
</body>
</html>